from flask import Flask, render_template
app = Flask(__name__)

@app.route("/")
def landing():
    return "Go to /play/ to start"

@app.route("/play")
def playIndex():
    x = int(3)
    return render_template('play.html', x = x )

@app.route("/play/<x>/<color>")
def play(x=3, color = 'dodgerblue' ):
    x = int(x)
    return render_template('play.html', x = x, color = color )

if __name__=="__main__":
    app.run(debug=True)