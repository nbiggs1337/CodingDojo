﻿using System;

namespace Phones
{
    class Program
    {
        static void Main(string[] args)
        {
            Galaxy S20 = new Galaxy("S20+", 98, "Verizon", "Dooo do doo dooooo");
            Nokia fivedot3 = new Nokia("")
            
            
            
            
        }
    }
}
