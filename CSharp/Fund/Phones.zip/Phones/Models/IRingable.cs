namespace Phones
{
    public interface IRingable
    {
        
        string Ring();
        
        string Unlock();
        
        
        
        
        
        
        
    }
}