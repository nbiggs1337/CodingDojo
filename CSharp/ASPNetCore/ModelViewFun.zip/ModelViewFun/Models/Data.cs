namespace ModelViewFun.Models
{
    public class Data
    {
        public string data {get;set;}
    }
}